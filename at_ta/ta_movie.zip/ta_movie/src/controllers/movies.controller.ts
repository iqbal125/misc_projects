import { Request, Response } from "express";
import * as movieService from "../services/movies";
import { getRatingsDB } from "../db/connections";
import { getRating } from "../services/ratings";

export const getMovies = async (req: Request, res: Response) => {
  try {
    let page = parseInt(req.query.page as string)
    let year = req.query.year as string

    const movies = await movieService.getAllMovies(page, year);

    res.json(movies);
  } catch (error) {
    res.status(500).json({ error: (error as Error).message });
  }
};

export const getMovieById = async (req: Request, res: Response) => {
  try {

    const movie = await movieService.getMovieById(parseInt(req.params.id));
    if (!movie) {
      res.status(404).json({ error: "Movie not found" });
      return;
    }
    res.json(movie);
  } catch (error) {
    res.status(500).json({ error: (error as Error).message });
  }
};
