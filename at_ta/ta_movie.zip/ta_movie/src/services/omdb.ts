
interface ExternalRating {
    Source: string;
    Value: string;
}

export const fetchOMDBRatings = async (imdbId: string): Promise<{ rottenTomatoesScore: string } | null> => {
    const OMDB_API_KEY = process.env.OMDB_API_KEY;

    if (!OMDB_API_KEY) {
        console.warn('OMDB API key not configured');
        return null;
    }

    try {
        const response = await fetch(
            `http://www.omdbapi.com/?i=${imdbId}&apikey=${OMDB_API_KEY}`
        );

        if (!response.ok) {
            throw "OMDB api error"
        }

        const data = await response.json();

        const rottenTomatoes = data.Ratings?.find(
            (rating: ExternalRating) => rating.Source === 'Rotten Tomatoes'
        );

        return {
            rottenTomatoesScore: rottenTomatoes?.Value || "N/A",
        };
    } catch (error) {
        throw error;
    }
};