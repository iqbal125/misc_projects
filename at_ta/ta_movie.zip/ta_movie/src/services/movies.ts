"use strict";

import { getMoviesDB, getRatingsDB } from "../db/connections";
import { MovieById, MovieByIdRes, Movies, ratingDBRes } from "../types";
import { fetchOMDBRatings } from "./omdb";


const formatCurrency = (budget: number): string => {
  if (!budget) return "$0"

  const formatedBudget = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
  }).format(budget as number)

  return formatedBudget
}

export const getAllMovies = async (page?: number, year?: string): Promise<Movies> => {

  //sql injection? sanitize input
  const LIMIT = 50
  const pageNum = page || 1
  const OFFSET = (pageNum - 1) * LIMIT

  let params = []

  const cols = `movieid, imdbid, title, genres, releaseDate, budget`
  let query = `SELECT ${cols} FROM movies `;

  const db = await getMoviesDB();

  if (year) {
    const yearCondition = `WHERE substring(releaseDate, 1, 4) = ? ORDER BY releaseDate DESC `
    query += yearCondition
    params.push(year)
  }

  const PaginationQuery = `LIMIT ? OFFSET ?;`;
  query += PaginationQuery
  params.push(LIMIT, OFFSET)

  let movies = await new Promise<Movies>((resolve, reject) => {
    db.all(query, params, (err: Error | null, rows: any[]) => {
      if (err) {
        reject(err);
      } else {
        resolve(rows || []);
      }
    });
  });

  movies = movies.map(movie => {
    return {
      ...movie, budget: formatCurrency(movie.budget as number)
    }
  }
  )

  return movies;
};


export const getMovieById = async (id: number): Promise<MovieByIdRes | null> => {
  const cols = `imdbId, title, overview, releaseDate, budget, runtime, json(genres) as genres, language, json(productionCompanies) as productionCompanies`
  const query = `SELECT ${cols} FROM movies WHERE movieId = ? ;`;
  const ratingQuery = `SELECT ROUND(AVG(rating), 2) as dbRating from ratings where movieId =?`

  const db = await getMoviesDB();
  const ratingsDB = await getRatingsDB();

  let movie = await new Promise<MovieById>((resolve, reject) => {
    db.get(query, [id], (err: Error | null, row: any) => {
      if (err) {
        reject(err);
      } else {
        resolve(row || null);
      }
    });
  });

  if (!movie) return null

  movie = {
    ...movie,
    budget: formatCurrency(movie.budget as number)
  };

  const rating = await new Promise<ratingDBRes>((resolve, reject) => {
    ratingsDB.get(ratingQuery, [id], (err: Error | null, row: any) => {
      if (err) {
        reject(err);
      } else {
        resolve(row || null);
      }
    });
  });

  const ratingExternal = await fetchOMDBRatings(movie.imdbId)
  console.log(ratingExternal)

  if (!rating) {
    return null
  }

  console.log({ movie, ...rating, ...ratingExternal })

  return { movie, ...rating, ...ratingExternal }

};
