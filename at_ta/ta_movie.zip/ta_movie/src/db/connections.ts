import { Database } from "sqlite3";
import { OPEN_READONLY } from "sqlite3";

export const initDatabase = (): Promise<{
  moviesDB: Database;
  ratingsDB: Database;
}> => {
  return new Promise((resolve, reject) => {
    const moviesDB = new Database(
      "./model/movies.db",
      OPEN_READONLY,
      (err: Error | null) => {
        if (err) {
          console.error("Error opening movies database:", err.message);
          reject(err);
          return;
        }
        console.log("Movies database opened successfully");

        const ratingsDB = new Database(
          "./model/ratings.db",
          OPEN_READONLY,
          (err: Error | null) => {
            if (err) {
              console.error("Error opening ratings database:", err.message);
              moviesDB.close();
              reject(err);
              return;
            }
            console.log("Ratings database opened successfully");
            resolve({ moviesDB, ratingsDB });
          }
        );
      }
    );
  });
};

export const getMoviesDB = (): Promise<Database> => {
  return initDatabase().then(({ moviesDB }) => moviesDB);
};

export const getRatingsDB = (): Promise<Database> => {
  return initDatabase().then(({ ratingsDB }) => ratingsDB);
};

export const closeAllConnections = (dbs: {
  moviesDB: Database;
  ratingsDB: Database;
}): void => {
  dbs.moviesDB.close();
  dbs.ratingsDB.close();
  console.log("All database connections closed");
};
