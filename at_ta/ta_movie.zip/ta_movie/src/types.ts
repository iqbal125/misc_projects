type ProductionCompany = {
    id: number;
    name: string;
};

type Genre = {
    id: number;
    name: string;
};

export type Movie = {
    movieId: number;
    imdbId: string;
    title: string;
    genres: Genre[];
    releaseDate: string;
    budget: number | string;
};

export type Movies = Movie[]

export type MovieById = {
    movieId?: number;
    imdbId: string;
    title: string;
    overview: string;
    releaseDate: string;
    budget: number | string;
    runtime: number;
    genres: Genre[];
    language: string | null;
    productionCompanies: ProductionCompany[];
};

export interface ratingDBRes {
    dbRating: number;
}

export interface MovieByIdRes extends ratingDBRes {
    movie: MovieById;
};
