import { getAllMovies, getMovieById } from "../../src/services/movies";
import { getMoviesDB, getRatingsDB } from "../../src/db/connections";
import { describe, expect, jest, beforeEach, afterEach, it } from '@jest/globals';
import { Movie, MovieById, Movies, ratingDBRes } from "../../src/types";
import { fetchOMDBRatings } from "../../src/services/omdb";

// Mock the database connection
jest.mock("../../src/db/connections");
jest.mock("../../src/services/omdb")
const mockGetMoviesDB = getMoviesDB as jest.MockedFunction<typeof getMoviesDB>;
const mockGetRatingsDB = getRatingsDB as jest.MockedFunction<typeof getRatingsDB>;
const mockedFetchOMDBRatings = fetchOMDBRatings as jest.MockedFunction<typeof fetchOMDBRatings>;

describe("Movies Service", () => {
  let mockDb: any;
  let mockRatingsDb: any;

  beforeEach(() => {
    mockDb = {
      all: jest.fn(),
      get: jest.fn(),
    };
    mockRatingsDb = {
      get: jest.fn(),
    };
    mockGetMoviesDB.mockResolvedValue(mockDb);
    mockGetRatingsDB.mockResolvedValue(mockRatingsDb);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  // NOTE: Here are some tests to get you started.
  // Please note that writing your own automated tests is not required for this task,
  // but you can use them to help understand your code's testability and functionality.

  describe("getAllMovies", () => {
    it("should return all movies successfully", async () => {
      const mockMovies: Movies = [
        {
          movieId: 2,
          imdbId: "tt0094675",
          title: "Ariel",
          genres: [
            { id: 18, name: "Drama" },
            { id: 80, name: "Crime" }
          ],
          releaseDate: "1988-10-21",
          budget: 0
        },
        {
          movieId: 3,
          imdbId: "tt0092149",
          title: "Shadows in Paradise",
          genres: [
            { id: 18, name: "Drama" },
            { id: 35, name: "Comedy" }
          ],
          releaseDate: "1986-10-16",
          budget: 0
        }
      ];

      mockDb.all.mockImplementation(
        (query: string, params: any[], callback: Function) => {
          callback(null, mockMovies);
        }
      );

      const result = await getAllMovies();

      expect(result).toEqual([{ ...mockMovies[0], budget: "$0" }, { ...mockMovies[1], budget: "$0" }]);
    });

    it("should handle database errors", async () => {
      const mockError = new Error("Database connection failed");

      mockDb.all.mockImplementation(
        (query: string, params: any[], callback: Function) => {
          callback(mockError, null);
        }
      );

      await expect(getAllMovies()).rejects.toThrow(
        "Database connection failed"
      );
    });

    it("should return empty array when no movies found", async () => {
      mockDb.all.mockImplementation(
        (query: string, params: any[], callback: Function) => {
          callback(null, []);
        }
      );

      const result = await getAllMovies();

      expect(result).toEqual([]);
    });
  });

  describe("getMovieById", () => {
    it("should return a movie by id successfully", async () => {
      const mockMovieRes: MovieById = {
        movieId: 1,
        imdbId: "tt0094675",
        title: "Ariel",
        overview: "Taisto Kasurinen is a Finnish coal miner whose father has just committed suicide and who is framed for a crime he did not commit. In jail, he starts to dream about leaving the country and starting a new life. He escapes from prison but things don't go as planned...",
        releaseDate: "1988-10-21",
        budget: 10000,
        runtime: 69,
        genres: [{ "id": 18, "name": "Drama" }, { "id": 80, "name": "Crime" }],
        language: null,
        productionCompanies: [{ "name": "Villealfa Filmproduction Oy", "id": 2303 }, { "name": "Finnish Film Foundation", "id": 2396 }]
      };

      const mockRatingRes: ratingDBRes = {
        dbRating: 3.4,
      }

      const mockExternalRatingRes = { rottenTomatoesScore: "65%" }

      mockDb.get.mockImplementation(
        (query: string, params: any[], callback: Function) => {
          callback(null, mockMovieRes);
        }
      );

      mockedFetchOMDBRatings.mockResolvedValueOnce(mockExternalRatingRes)

      mockRatingsDb.get.mockImplementation(
        (query: string, params: any[], callback: Function) => {
          callback(null, mockRatingRes);
        }
      );

      const result = await getMovieById(1);

      expect(mockDb.get).toHaveBeenCalledTimes(1)
      expect(mockRatingsDb.get).toHaveBeenCalledTimes(1)
      expect(mockedFetchOMDBRatings).toHaveBeenCalledTimes(1)
      expect(result).toEqual({
        movie: { ...mockMovieRes, budget: '$10,000' }, ...mockRatingRes, ...mockExternalRatingRes
      });
    });

    it("should display budget in USD format", async () => {
      const mockMovie: Movie = {
        movieId: 1,
        imdbId: "tt0094675",
        title: "Ariel",
        genres: [
          { id: 18, name: "Drama" },
          { id: 80, name: "Crime" }
        ],
        releaseDate: "1988-10-21",
        budget: 10000
      };

      const mockRatingRes = {
        rottenTomatoRating: 3.4,
        rating_count: 107
      }

      mockDb.get.mockImplementation(
        (query: string, params: any[], callback: Function) => {
          callback(null, mockMovie);
        }
      );


      mockRatingsDb.get.mockImplementation(
        (query: string, params: any[], callback: Function) => {
          callback(null, mockRatingRes);
        }
      );


      const result = await getMovieById(1);
      expect(result?.movie?.budget).toBe("$10,000");
    });

    it("should return null when movie not found", async () => {
      mockDb.get.mockImplementation(
        (query: string, params: any[], callback: Function) => {
          callback(null, null);
        }
      );

      const result = await getMovieById(999);

      expect(result).toBeNull();
    });

    it("should handle database errors", async () => {
      const mockError = new Error("Database query failed");

      mockDb.get.mockImplementation(
        (query: string, params: any[], callback: Function) => {
          callback(mockError, null);
        }
      );

      await expect(getMovieById(1)).rejects.toThrow("Database query failed");
    });
  });
});
