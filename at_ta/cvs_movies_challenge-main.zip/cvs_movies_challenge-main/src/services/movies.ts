"use strict";

import { getMoviesDB } from "../db/connections";

export const getAllMovies = async (): Promise<any[]> => {
  const query = "SELECT * FROM movies LIMIT 100;";

  const db = await getMoviesDB();

  return new Promise((resolve, reject) => {
    db.all(query, [], (err: Error | null, rows: any[]) => {
      if (err) {
        reject(err);
      } else {
        resolve(rows || []);
      }
    });
  });
};

export const getMovieById = async (id: number): Promise<any> => {
  const query = "SELECT * FROM movies WHERE movieId = ?;";

  const db = await getMoviesDB();

  return new Promise((resolve, reject) => {
    db.get(query, [id], (err: Error | null, row: any) => {
      if (err) {
        reject(err);
      } else {
        resolve(row || null);
      }
    });
  });
};
