import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import Navigation from '../components/Navigation';
import Hero from '../components/Hero';
import TodoContainer from '../components/TodoContainer';
import { fetchTodos } from '../api/todos';
import type { Todo } from '../types/types';


const Home: React.FC = () => {
    const {
        data: todos,
        isLoading,
        error,
        isError
    } = useQuery({
        queryKey: ['todos'],
        queryFn: fetchTodos,
    });

    const [localTodos, setLocalTodos] = useState<Todo[]>([]);

    useEffect(() => {
        if (todos) {
            setLocalTodos(todos);
        }
    }, [todos]);

    const toggleTodoById = (todos: Todo[], id: number) => {
        return todos.map(todo => {
            if (todo.id === id) {
                return { ...todo, completed: !todo.completed };
            }
            return todo;
        });
    };

    const handleToggleTodo = (id: number) => {
        setLocalTodos(prev => toggleTodoById(prev, id));
    };

    return (
        <div className="min-h-screen bg-gray-50">
            <Navigation />
            <div className="max-w-xl mx-auto p-6 space-y-6">
                <Hero />
                <TodoContainer
                    todos={localTodos}
                    isLoading={isLoading}
                    isError={isError}
                    error={error}
                    onToggleTodo={handleToggleTodo}
                />
            </div>
        </div>
    );
};

export default Home;