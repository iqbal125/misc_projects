

const Hero = () => {
    return (
        <div>
            <h1>Todo List</h1>
        </div>
    );
};

export default Hero;