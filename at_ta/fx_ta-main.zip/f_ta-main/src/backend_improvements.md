For backend implementation notes: 

- Use own server instead of public api. 
- Add authentication for security, possibly jwt token auth
- Add CRUD routes POST, PUT, DELETE
- Add request validation to backend
- Add SQL Database to add persistant storage to save todos

