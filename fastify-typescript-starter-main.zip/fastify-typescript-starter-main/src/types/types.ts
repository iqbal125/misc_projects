export interface AuthRequestI {
  payload: {
    user_id: string;
  };
}
