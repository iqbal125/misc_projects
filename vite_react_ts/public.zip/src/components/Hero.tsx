

const Hero = () => {
    return (
        <div>
            <h1>Hero Text</h1>
        </div>
    );
};

export default Hero;