#!/usr/bin/env python3
import sys
import csv
from decimal import Decimal, ROUND_HALF_UP
from collections import defaultdict

def read_csv(path):
    with open(path, newline='', encoding='utf-8') as f:
        return list(csv.DictReader(f))

def format_rate(d):
    return str(d.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))

def main():
    if len(sys.argv) != 4:
        print("usage: slcsp.py slcsp.csv plans.csv zips.csv", file=sys.stderr)
        sys.exit(1)

    slcsp_path, plans_path, zips_path = sys.argv[1], sys.argv[2], sys.argv[3]

    slcsp_rows = read_csv(slcsp_path)
    plans_rows = read_csv(plans_path)
    zips_rows = read_csv(zips_path)

    zip_to_areas = defaultdict(set)
    for r in zips_rows:
        zipc = r.get("zipcode") or r.get("zip") or r.get("ZIP Code") 
        state = r.get("state")
        ra = r.get("rate_area") or r.get("rate area") or r.get("ratearea")
        if zipc and state and ra:
            zip_to_areas[zipc].add((state, ra))

    area_to_rates = defaultdict(set) 
    for r in plans_rows:
        if (r.get("metal_level") or "").strip().lower() != "silver":
            continue
        state = r.get("state")
        ra = r.get("rate_area") or r.get("rate area") or r.get("ratearea")
        rate_str = r.get("rate")
        if not (state and ra and rate_str):
            continue
        try:
            rate = Decimal(rate_str)
        except Exception:
            continue
        area_to_rates[(state, ra)].add(rate)

    area_to_sorted = {k: sorted(v) for k, v in area_to_rates.items()}

    out = []
    for r in slcsp_rows:
        zipc = r.get("zipcode") or r.get("zip")
        rate_out = ""
        if zipc in zip_to_areas:
            areas = zip_to_areas[zipc]
            if len(areas) == 1:
                (state, ra) = next(iter(areas))
                rates = area_to_sorted.get((state, ra), [])
       
                if len(rates) >= 2:
                    rate_out = format_rate(rates[1])
                else:
                    rate_out = ""
            else:
                rate_out = ""
        else:
            rate_out = ""

        out.append((zipc, rate_out))


    w = csv.writer(sys.stdout, lineterminator="\n")
    w.writerow(["zipcode", "rate"])
    for zipc, rate_out in out:
        w.writerow([zipc, rate_out])

if __name__ == "__main__":
    main()
