export const errorMessageGeneral = 'Something Went Wrong';

export const API_URL = 'http://localhost:3000';
