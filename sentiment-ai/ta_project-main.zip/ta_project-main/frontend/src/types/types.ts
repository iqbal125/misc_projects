export interface Sentitment {
  id: string;
  text: string;
  sentiment: string;
  score: number;
  createdAt: Date;
}
