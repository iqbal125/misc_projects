import 'dotenv/config';
import mongoose from 'mongoose';
import { QuestionSchema } from '../src/quiz/schemas/question.schema';

const Question = mongoose.model('Question', QuestionSchema);


async function seed() {
  const mongoUri = process.env.MONGO_URI;
  if (!mongoUri) {
    console.error('MONGO_URI not set in .env');
    process.exit(1);
  }

  await mongoose.connect(mongoUri);
  //modify url params to control the type of questions available if needed
  const response = await fetch('https://opentdb.com/api.php?amount=30&category=11&difficulty=easy&type=multiple');

  const { results } = await response.json();

  await Question.insertMany(results);
  console.log('Seed complete');
  process.exit();
}

seed();
