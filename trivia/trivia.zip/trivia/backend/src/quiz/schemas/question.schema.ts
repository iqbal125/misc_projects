import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type QuestionDocument = Question & Document;

@Schema()
export class Question {
  @Prop()
  category: string;

  @Prop()
  type: string;

  @Prop()
  difficulty: string;

  @Prop()
  question: string;

  @Prop()
  correct_answer: string;

  @Prop([String])
  incorrect_answers: string[];
}

export const QuestionSchema = SchemaFactory.createForClass(Question);
