import React from 'react';
import { useDispatch } from 'react-redux';
import { setCategory } from '../store/quizSlice';
import { useGetCategoriesQuery } from '../store/quizApi';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const CategorySelector: React.FC = () => {
    const dispatch = useDispatch();
    const { data: categories = [] } = useGetCategoriesQuery();

    return (
        <div className="space-y-1">
            <Label>Category</Label>
            <Select onValueChange={(value) => dispatch(setCategory(value))}>
                <SelectTrigger className="w-full">
                    <SelectValue placeholder="Choose a category" />
                </SelectTrigger>
                <SelectContent>
                    {categories.map((cat) => (
                        <SelectItem key={cat} value={cat}>
                            {cat}
                        </SelectItem>
                    ))}
                </SelectContent>
            </Select>
        </div>
    );
};

export default CategorySelector;


