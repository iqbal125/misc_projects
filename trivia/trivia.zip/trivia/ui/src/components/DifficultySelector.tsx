import React from 'react';
import { useDispatch } from 'react-redux';
import { setDifficulty } from '../store/quizSlice';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const DifficultySelector: React.FC = () => {
    const dispatch = useDispatch();

    return (
        <div className="space-y-1">
            <Label>Difficulty</Label>
            <Select onValueChange={(value) => dispatch(setDifficulty(value as any))}>
                <SelectTrigger className="w-full">
                    <SelectValue placeholder="Choose difficulty" />
                </SelectTrigger>
                <SelectContent>
                    <SelectItem value="easy">Easy</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="hard">Hard</SelectItem>
                </SelectContent>
            </Select>
        </div>
    );
};

export default DifficultySelector;
