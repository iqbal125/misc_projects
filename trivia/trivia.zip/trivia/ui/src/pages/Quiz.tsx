import { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useGetQuizQuery, useSubmitQuizMutation } from '../store/quizApi';
import { setAnswer, setQuestions, setResults, setCanSubmit } from '../store/quizSlice';
import type { RootState } from '../store';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import he from 'he';


function shuffleArray<T>(arr: T[]): T[] {
    return [...arr].sort(() => Math.random() - 0.5);
}

const Quiz: React.FC = () => {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const { category, difficulty, amount, answers, questions } = useSelector((state: RootState) => state.quiz);
    const { data = [], isLoading } = useGetQuizQuery({ category: category!, difficulty: difficulty!, amount });
    const [submitQuiz] = useSubmitQuizMutation();
    const canSubmit = useSelector((state: RootState) => state.quiz.canSubmit);

    useEffect(() => {
        if (data.length > 0) {
            const withOptions = data.map((q) => ({
                ...q,
                options: shuffleArray([...q.options]),
            }));
            dispatch(setQuestions(withOptions));
        }
    }, [data]);

    useEffect(() => {
        const allAnswered = Object.keys(answers).length === questions.length;
        dispatch(setCanSubmit(allAnswered));
    }, [answers, questions.length, dispatch]);

    const handleSubmit = async () => {
        const payload = questions.map((q, idx) => ({
            id: q.id,
            selected: answers[idx],
        }));

        const result = await submitQuiz({ answers: payload }).unwrap();
        dispatch(setResults(result.results));
        navigate('/result');
    };

    return (
        <div>
            {isLoading ? (
                <p className="text-center">Loading...</p>
            ) : questions.length === 0 ? (
                <div className='space-y-4'>
                    <p className="text-center text-xl">No questions found.</p>
                    <Button
                        onClick={() => {
                            navigate('/');
                        }}
                        className="w-full bg-gray-300 text-black hover:bg-gray-400"
                    >
                        Start New Quiz
                    </Button>
                </div>

            ) : (
                <div className="min-h-screen flex items-center justify-center px-4">
                    <div className="w-full max-w-3xl p-6 bg-white rounded-2xl shadow space-y-8">
                        <h2 className="text-2xl font-semibold text-center">Quiz: {category}</h2>

                        {questions.map((q, idx) => (
                            <Card key={q.id}>
                                <CardContent className="space-y-2 py-4">
                                    <p className="font-medium">{`${idx + 1}. ${he.decode(q.question)}`}</p>
                                    <div className="flex flex-wrap gap-2">
                                        {q.options.map((ans) => {
                                            const isSelected = answers[idx] === ans;
                                            return (
                                                <button
                                                    key={ans}
                                                    type="button"
                                                    className={`px-4 py-2 rounded-xl border text-sm transition ${isSelected
                                                        ? 'bg-green-600 text-white border-green-600'
                                                        : 'text-green-600 border-green-600 hover:border-green-700'
                                                        }`}
                                                    onClick={() =>
                                                        dispatch(setAnswer({ questionIndex: idx, answer: ans }))
                                                    }
                                                >
                                                    {he.decode(ans)}
                                                </button>
                                            );
                                        })}
                                    </div>
                                </CardContent>
                            </Card>
                        ))}

                        {canSubmit && (
                            <div className="text-center pt-4">
                                <Button
                                    onClick={handleSubmit}
                                    className="bg-black text-white hover:bg-gray-800"
                                >
                                    Submit Quiz
                                </Button>
                            </div>
                        )}
                    </div>
                </div>
            )
            }
        </div >
    );

};

export default Quiz;
