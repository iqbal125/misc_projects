import { useSelector, useDispatch } from 'react-redux';
import type { RootState } from '../store';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { useNavigate } from 'react-router-dom';
import { resetQuiz } from '../store/quizSlice';
import { getAnswerStyle } from '@/lib/helpers';
import he from 'he';


const Result: React.FC = () => {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const results = useSelector((state: RootState) => state.quiz.results);
    const questions = useSelector((state: RootState) => state.quiz.questions);

    if (!results.length || !questions.length) return <p className="text-center">No results found.</p>;

    const score = results.filter((r) => r.isCorrect).length;

    const getScoreColor = (score: number): string => {
        if (score <= 1) return 'bg-red-600';
        if (score <= 3) return 'bg-yellow-500';
        return 'bg-green-600';
    };


    return (
        <div className="min-h-screen flex items-center justify-center px-4">
            <div className="w-full max-w-3xl p-6 bg-white rounded-2xl shadow space-y-8">
                <h2 className="text-2xl font-semibold text-center">
                    Your Score: {score} / {results.length}
                </h2>

                {results.map((res, idx) => {
                    const question = questions.find((q) => q.id === res.id);
                    if (!question) return null;

                    return (
                        <Card key={res.id}>
                            <CardContent className="space-y-2 py-4">
                                <p className="font-medium">{`${idx + 1}. ${he.decode(question.question)}`}</p>
                                <div className="flex flex-wrap gap-2">
                                    {question.options.map((ans) => {
                                        const result = results.find((r) => r.id === question.id);
                                        const isCorrect = ans === result?.correct;
                                        const isSelected = ans === result?.selected;


                                        return (
                                            <span
                                                key={ans}
                                                className={`px-4 py-2 rounded-xl border text-sm transition ${getAnswerStyle({
                                                    isCorrect,
                                                    isSelected,
                                                })}`}
                                            >
                                                {he.decode(ans)}
                                            </span>
                                        );
                                    })}
                                </div>
                            </CardContent>
                        </Card>
                    );
                })}

                <div className={`w-full ${getScoreColor(score)} text-white text-xs text-center py-2 rounded-md`}>
                    Score: {score} / {results.length}
                </div>

                <div className="pt-4">
                    <Button
                        onClick={() => {
                            dispatch(resetQuiz());
                            navigate('/');
                        }}
                        className="w-full bg-gray-300 text-black hover:bg-gray-400"
                    >
                        Start New Quiz
                    </Button>
                </div>
            </div>
        </div>
    );
};

export default Result;
