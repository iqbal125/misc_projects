import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Provider } from 'react-redux';
import { store } from './store';

import Home from './pages/Home';
import Quiz from './pages/Quiz';
import Result from './pages/Result';

const App: React.FC = () => {
  return (
    <Provider store={store}>
      <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
        <div className={` bg-white shadow-lg rounded-2xl p-6 space-y-6`}>
          <Router>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/quiz" element={<Quiz />} />
              <Route path="/result" element={<Result />} />
            </Routes>
          </Router>
        </div>
      </div>
    </Provider >
  );
};

export default App;
