import { createSlice, type PayloadAction } from '@reduxjs/toolkit';

interface Question {
    id: string;
    question: string;
    options: string[];
}

interface Result {
    id: string;
    selected: string;
    correct: string;
    isCorrect: boolean;
}

interface QuizState {
    category: string | null;
    difficulty: 'easy' | 'medium' | 'hard' | null;
    amount: number;
    questions: Question[];
    answers: Record<number, string>;
    results: Result[];
    canSubmit: boolean;
}

const initialState: QuizState = {
    category: null,
    difficulty: null,
    amount: 5,
    questions: [],
    answers: {},
    results: [],
    canSubmit: false,
};

const quizSlice = createSlice({
    name: 'quiz',
    initialState,
    reducers: {
        setCategory: (state, action: PayloadAction<string>) => {
            state.category = action.payload;
        },
        setDifficulty: (state, action: PayloadAction<'easy' | 'medium' | 'hard'>) => {
            state.difficulty = action.payload;
        },
        setAmount: (state, action: PayloadAction<number>) => {
            state.amount = action.payload;
        },
        setQuestions: (state, action: PayloadAction<Question[]>) => {
            state.questions = action.payload;
        },
        setAnswer: (state, action: PayloadAction<{ questionIndex: number; answer: string }>) => {
            state.answers[action.payload.questionIndex] = action.payload.answer;
        },
        setResults: (state, action: PayloadAction<Result[]>) => {
            state.results = action.payload;
        },
        setCanSubmit: (state, action: PayloadAction<boolean>) => {
            state.canSubmit = action.payload;
        },
        resetQuiz: () => initialState,
    },
});

export const {
    setCategory,
    setDifficulty,
    setAmount,
    setQuestions,
    setAnswer,
    setResults,
    setCanSubmit,
    resetQuiz,
} = quizSlice.actions;

export default quizSlice.reducer;
