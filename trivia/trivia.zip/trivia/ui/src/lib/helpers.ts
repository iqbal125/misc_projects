export function getAnswerStyle({
    isCorrect,
    isSelected,
}: {
    isCorrect: boolean;
    isSelected: boolean;
}): string {
    if (isCorrect && isSelected) {
        return 'bg-green-600 text-white border-green-600';
    } else if (isCorrect) {
        return 'bg-green-600 text-white border-green-600';
    } else if (isSelected) {
        return 'bg-red-600 text-white border-red-600';
    } else {
        return 'text-green-600 border-green-600';
    }
}
