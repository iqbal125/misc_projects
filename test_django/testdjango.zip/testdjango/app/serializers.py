from rest_framework import serializers
from django.db.models import Avg
from .models import Movie, Rating


class MovieSerializer(serializers.ModelSerializer):
    rating = serializers.SerializerMethodField()

    class Meta:
        model = Movie
        fields = ['id', 'title', 'rating']

    def get_rating(self, obj):
        avg_rating = obj.ratings.aggregate(Avg('value'))['value__avg']
        return avg_rating if avg_rating is not None else None


class RatingSerializer(serializers.ModelSerializer):
    class Meta:
        model = Rating
        fields = ['id', 'movie', 'value']

    def validate_value(self, value):
        if value < 1 or value > 5:
            raise serializers.ValidationError("Rating value must be between 1 and 5.")
        return value
