from django.urls import include, path


from app import views

# Wire up your API routes here
urlpatterns = [
	path('health/', views.health, name='health'),
	path('movies/', views.create_movie, name='create_movie'),
	path('movies/<int:movie_id>/', views.get_movie, name='get_movie'),
	path('ratings/', views.create_rating, name='create_rating'),
]
