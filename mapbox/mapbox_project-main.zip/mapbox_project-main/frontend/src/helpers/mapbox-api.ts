import draw from '../services/mapbox-draw';
import { Polygon } from '../types';
import { MapboxMap } from 'react-map-gl';
import { QueryClient } from '@tanstack/react-query';
import axiosClient from '../services/axios';

export interface setDefaultPolygonPropsI {
  mapRef: React.MutableRefObject<MapboxMap | null>;
  queryClient: QueryClient;
  id: string;
}

export const setDefaultPolygon = async ({ mapRef, queryClient, id }: setDefaultPolygonPropsI) => {
  const data: Polygon[] | undefined = queryClient.getQueryData(['polygons']);

  if (id && data) {
    const polygon = data.filter((polygon) => polygon.id === id);
    const coordinates = polygon[0].coordinates;

    const center = polygon[0].center as [number, number];

    mapRef.current?.setCenter(center);
    mapRef.current?.setZoom(polygon[0].zoom);

    draw.add({
      type: 'FeatureCollection',
      features: [
        {
          type: 'Feature',
          properties: {},
          geometry: {
            type: 'Polygon',
            // @ts-expect-error, position is not exported, number[][] is compatible
            coordinates
          }
        }
      ]
    });
  } else if (id && !data) {
    const res = await axiosClient.get(`/polygon/${id}`);

    const polygon = res?.data;
    const coordinates = polygon?.coordinates;

    const center = polygon.center as [number, number];

    mapRef.current?.setCenter(center);
    mapRef.current?.setZoom(polygon.zoom);

    draw.add({
      type: 'FeatureCollection',
      features: [
        {
          type: 'Feature',
          properties: {},
          geometry: {
            type: 'Polygon',
            coordinates
          }
        }
      ]
    });
  } else {
    throw 'Polygon not Found';
  }
};
