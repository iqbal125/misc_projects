import { Map as MapboxMap } from 'mapbox-gl';

export interface AddSourcePropsI {
  mapRef: React.MutableRefObject<MapboxMap | null>;
  coordinates: number[][];
  id: string;
}

export const addSource = ({ mapRef, coordinates, id }: AddSourcePropsI) => {
  if (mapRef.current) {
    mapRef.current.addSource(id, {
      type: 'geojson',
      data: {
        type: 'Feature',
        geometry: {
          type: 'Polygon',
          //@ts-expect-error, Position[] is not exported, Position is [number, ...]
          coordinates
        },
        properties: {}
      }
    });
  }
};

export interface AddLayerPropsI {
  mapRef: React.MutableRefObject<MapboxMap | null>;
  id: string;
}

export const addLayer = ({ mapRef, id }: AddLayerPropsI) => {
  if (mapRef.current) {
    mapRef.current.addLayer({
      id: `fill-${id}`,
      type: 'fill',
      source: id,
      layout: {},
      paint: {
        'fill-color': '#0080ff',
        'fill-opacity': 0.5
      }
    });

    mapRef.current.addLayer({
      id: `outline-${id}`,
      type: 'line',
      source: id,
      layout: {},
      paint: {
        'line-color': '#000',
        'line-width': 3
      }
    });
  }
};
