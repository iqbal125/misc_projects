import React, { useEffect, useRef, useState } from 'react';
import { Map as MapboxMap } from 'mapbox-gl';
import { DrawCreateEvent } from '@mapbox/mapbox-gl-draw';

import { zodResolver } from '@hookform/resolvers/zod';
import mapboxgl from '../services/mapbox-gl';
import draw from '../services/mapbox-draw';
import 'mapbox-gl/dist/mapbox-gl.css';
import '@mapbox/mapbox-gl-draw/dist/mapbox-gl-draw.css';
import { AddSourcePropsI, AddLayerPropsI, addLayer, addSource } from '../helpers/mapbox-draw';
import { fetchAllPolygons, postPolygon } from '../api/polygon';
import { useQuery } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';

import { FormData, schema } from '../types/validations';
import { useQueryClient, useMutation } from '@tanstack/react-query';

import { toast } from 'react-toastify';
import { GenericErrorText } from '../utils/constants';
import PolygonForm from '../components/Form';
import PolygonList from '../components/PolygonList';

const MapboxCreate: React.FC = () => {
  let mapContainerRef = useRef<HTMLDivElement | null>(null);
  let mapRef = useRef<MapboxMap | null>(null);

  const [polygonId, setPolygonId] = useState('');
  const [polygonCoors, setPolygonCoors] = useState<number[][]>([]);

  const queryClient = useQueryClient();
  const { data, error, isLoading } = useQuery({
    queryKey: ['polygons'],
    queryFn: () => fetchAllPolygons()
  });

  if (error) toast.error(GenericErrorText);

  const mutation = useMutation({
    mutationFn: postPolygon,
    onSuccess: () => {
      toast.success('Polygon Created');
      queryClient.invalidateQueries({ queryKey: ['polygons'] });
    },
    onError: (error: any) => {
      toast.error('Create Polygon Failed');
      console.error('Error updating polygon:', error);
    }
  });

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    setError
  } = useForm<FormData>({
    resolver: zodResolver(schema)
  });

  const onSubmit = async (formData: { polygonTitle: string }) => {
    console.log(polygonId, polygonCoors);
    if (polygonId === '' || polygonCoors.length === 0) {
      setError('polygonTitle', {
        type: 'custom',
        message: 'Please set Polygon with at least 3 points'
      });
      throw 'Polygon not Set';
    }

    if (mapRef.current) {
      const { lng, lat } = mapRef.current.getCenter();
      const zoom = mapRef.current.getZoom();

      const polygonData = {
        id: polygonId,
        name: formData.polygonTitle,
        coordinates: polygonCoors,
        zoom,
        center: [lng, lat]
      };

      mutation.mutate(polygonData);
    }
  };

  const drawCreate = async (e: DrawCreateEvent) => {
    //@ts-expect-error, coordinates property exists in the event
    const coordinates = e.features[0].geometry.coordinates as number[][];
    const id = String(e.features[0].id);

    setPolygonId(id);
    setPolygonCoors(coordinates);

    if (mapRef.current) {
      const addSourceProps: AddSourcePropsI = { mapRef, coordinates, id };
      addSource(addSourceProps);

      const addLayerProps: AddLayerPropsI = { mapRef, id };
      addLayer(addLayerProps);

      mapRef.current.removeControl(draw);
    }
  };

  const clearMap = () => {
    setPolygonId('');
    setPolygonCoors([]);
    reset();
    mapRef.current?.removeLayer(`fill-${polygonId}`);
    mapRef.current?.removeLayer(`outline-${polygonId}`);
    mapRef.current?.addControl(draw);
  };

  useEffect(() => {
    if (mapContainerRef.current) {
      mapRef.current = new mapboxgl.Map({
        container: mapContainerRef.current,
        style: 'mapbox://styles/mapbox/light-v11',
        center: [-91.874, 42.76],
        zoom: 6
      });

      mapRef.current.addControl(draw);

      mapRef.current.on('draw.create', drawCreate);

      mapRef.current.on('draw.delete', clearMap);

      //mapRef.current.on("load", () => {})
    }

    return () => {
      if (mapRef.current) {
        mapRef.current.remove();
      }
    };
  }, []);

  return (
    <div id="map">
      <div ref={mapContainerRef} style={{ height: '500px' }}></div>
      <div className="container mx-auto p-4 flex justify-center">
        <PolygonForm
          handleSubmit={handleSubmit}
          onSubmit={onSubmit}
          clearMap={clearMap}
          errors={errors}
          register={register}
        />
      </div>
      <div className="mt-6">{data && <PolygonList data={data} isLoading={isLoading} />}</div>
    </div>
  );
};

export default MapboxCreate;
