import React, { useEffect, useRef } from 'react';
import { Map as MapboxMap } from 'mapbox-gl';

import mapboxgl from '../services/mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import '@mapbox/mapbox-gl-draw/dist/mapbox-gl-draw.css';
import { useQueryClient } from '@tanstack/react-query';

import { addLayer, addSource, AddLayerPropsI, AddSourcePropsI } from '../helpers/mapbox-draw';

import { useParams } from 'react-router-dom';

import { Polygon } from '../types';
import { fetchOnePolygon } from '../api/polygon';
import { toast } from 'react-toastify';

const MapboxView: React.FC = () => {
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<MapboxMap | null>(null);
  const params = useParams();
  const queryClient = useQueryClient();
  const id = params.id;

  const setDefaultPolygonView = async () => {
    const dataCache: Polygon[] | undefined = queryClient.getQueryData(['polygons']);
    const polygon = dataCache?.filter((polygon) => polygon.id === id);

    if (id && polygon) {
      const coordinates = polygon[0].coordinates;

      const addSourceProps: AddSourcePropsI = { mapRef, coordinates, id };
      addSource(addSourceProps);

      const addLayerProps: AddLayerPropsI = { mapRef, id };
      addLayer(addLayerProps);

      const center = polygon[0].center as [number, number];

      mapRef.current?.setCenter(center);
      mapRef.current?.setZoom(polygon[0].zoom);
    } else if (id && !polygon) {
      try {
        const polygon = await queryClient.fetchQuery({
          queryKey: ['polygon', id],
          queryFn: () => fetchOnePolygon(id)
        });

        const { coordinates, zoom } = polygon;

        const addSourceProps: AddSourcePropsI = { mapRef, coordinates, id };
        addSource(addSourceProps);

        const addLayerProps: AddLayerPropsI = { mapRef, id };
        addLayer(addLayerProps);

        const center = polygon.center as [number, number];

        mapRef.current?.setCenter(center);
        mapRef.current?.setZoom(zoom);
      } catch (e) {
        console.log(e);
      }
    } else {
      toast.error('Polygon Not Found');
    }
  };

  useEffect(() => {
    if (mapContainerRef.current) {
      mapRef.current = new mapboxgl.Map({
        container: mapContainerRef.current,
        style: 'mapbox://styles/mapbox/light-v11',
        center: [-91.874, 42.76],
        zoom: 6
      });

      mapRef.current.on('load', () => {
        if (mapRef.current && id) {
          setDefaultPolygonView();
        }
      });
    }

    return () => {
      if (mapRef.current) {
        mapRef.current.remove();
      }
    };
  }, []);

  return (
    <div id="map">
      <div ref={mapContainerRef} style={{ height: '100vh' }}></div>
    </div>
  );
};

export default MapboxView;
