import React, { useEffect, useRef, useState } from 'react';
import { Map as MapboxMap } from 'mapbox-gl';
import { DrawCreateEvent, DrawUpdateEvent } from '@mapbox/mapbox-gl-draw';

import mapboxgl from '../services/mapbox-gl';
import draw from '../services/mapbox-draw';
import 'mapbox-gl/dist/mapbox-gl.css';
import '@mapbox/mapbox-gl-draw/dist/mapbox-gl-draw.css';
import { fetchOnePolygon, putPolygon } from '../api/polygon';

import { Polygon } from '../types';

import { useParams } from 'react-router-dom';
import { useQueryClient } from '@tanstack/react-query';

import { FormData, schema } from '../types/validations';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';

import { useMutation } from '@tanstack/react-query';
import { toast } from 'react-toastify';
import PolygonForm from '../components/Form';

const MapboxUpdate: React.FC = () => {
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<MapboxMap | null>(null);

  const [polygonId, setPolygonId] = useState('');
  const [polygonCoors, setPolygonCoors] = useState<number[][]>([]);

  const params = useParams();
  const id = params.id || '';

  const queryClient = useQueryClient();

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    reset,
    setError
  } = useForm<FormData>({
    resolver: zodResolver(schema)
  });

  const mutation = useMutation({
    mutationFn: putPolygon,
    onSuccess: () => {
      toast.success('Polygon Updated');
      queryClient.invalidateQueries({ queryKey: ['polygons'] });
    },
    onError: (error: any) => {
      toast.error('Polygon Failed to Update');
      console.error('Error updating polygon:', error);
    }
  });

  const onSubmit = async (formData: { polygonTitle: string }) => {
    console.log(polygonId, polygonCoors);

    if (polygonId === '' || polygonCoors.length === 0) {
      setError('polygonTitle', {
        type: 'custom',
        message: 'Please set Polygon with at least 3 points'
      });
      throw 'Polygon not Set';
    }

    if (mapRef.current) {
      const { lng, lat } = mapRef.current.getCenter();
      const zoom = mapRef.current.getZoom();

      const polygonData = {
        id: polygonId,
        name: formData.polygonTitle,
        coordinates: polygonCoors,
        zoom,
        center: [lng, lat]
      };

      mutation.mutate(polygonData);
    }
  };

  const drawUpdate = async (e: DrawUpdateEvent | DrawCreateEvent) => {
    //@ts-expect-error, coordinates property exists in the event
    const coordinates = e.features[0].geometry.coordinates as number[][];

    setPolygonId(id);
    setPolygonCoors(coordinates);
  };

  const clearMap = () => {
    setPolygonCoors([]);
    draw.deleteAll();
    reset();
  };

  const setDefaultPolygon = async () => {
    const dataCache: Polygon[] | undefined = queryClient.getQueryData(['polygons']);
    const polygon = dataCache?.filter((polygon) => polygon.id === id);

    if (id && polygon) {
      const coordinates = polygon[0].coordinates;

      const center = polygon[0].center as [number, number];

      setValue('polygonTitle', polygon[0].name);

      mapRef.current?.setCenter(center);
      mapRef.current?.setZoom(polygon[0].zoom);

      draw.add({
        type: 'FeatureCollection',
        features: [
          {
            type: 'Feature',
            properties: {},
            geometry: {
              type: 'Polygon',
              // @ts-expect-error, position is not exported, number[][] is compatible
              coordinates
            }
          }
        ]
      });
    } else if (id && !polygon) {
      try {
        const polygon = await queryClient.fetchQuery({
          queryKey: ['polygon', id],
          queryFn: () => fetchOnePolygon(id)
        });

        const { coordinates, name, zoom } = polygon;

        const center = polygon.center as [number, number];

        setValue('polygonTitle', name);

        mapRef.current?.setCenter(center);
        mapRef.current?.setZoom(zoom);

        draw.add({
          type: 'FeatureCollection',
          features: [
            {
              type: 'Feature',
              properties: {},
              geometry: {
                type: 'Polygon',
                //@ts-expect-error, number[][] is compatible type
                coordinates
              }
            }
          ]
        });
      } catch (error) {
        toast.error('Polygon Not Found');
        console.log(error);
      }
    } else {
      toast.error('Polygon Not Found');
    }
  };

  useEffect(() => {
    if (id) setPolygonId(id);

    if (mapContainerRef.current) {
      mapRef.current = new mapboxgl.Map({
        container: mapContainerRef.current,
        style: 'mapbox://styles/mapbox/light-v11',
        center: [-91.874, 42.76],
        zoom: 6
      });

      mapRef.current.addControl(draw);

      mapRef.current.on('draw.create', drawUpdate);
      mapRef.current.on('draw.update', drawUpdate);

      mapRef.current.on('draw.delete', clearMap);

      mapRef.current.on('load', () => {
        if (mapRef.current) {
          setDefaultPolygon();
        }
      });
    }

    return () => {
      if (mapRef.current) {
        mapRef.current.remove();
      }
    };
  }, []);

  return (
    <div id="map">
      <div ref={mapContainerRef} style={{ height: '500px' }}></div>
      <div className="container mx-auto p-4 flex justify-center">
        <PolygonForm
          handleSubmit={handleSubmit}
          onSubmit={onSubmit}
          clearMap={clearMap}
          errors={errors}
          register={register}
        />
      </div>
    </div>
  );
};

export default MapboxUpdate;
