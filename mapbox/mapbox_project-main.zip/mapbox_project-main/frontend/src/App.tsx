import './styles/App.css';
import 'mapbox-gl/dist/mapbox-gl.css';
import MapboxCreate from './pages/MapBoxCreate';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import Header from './components/Header';
import MapboxView from './pages/MapBoxView';
import MapboxEdit from './pages/MapBoxUpdate';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const queryClient = new QueryClient();

function App() {
  return (
    <div>
      <QueryClientProvider client={queryClient}>
        <Router>
          <Header />
          <Routes>
            <Route path="/" element={<MapboxCreate />} />
            <Route path="/view/:id" element={<MapboxView />} />
            <Route path="/edit/:id" element={<MapboxEdit />} />
          </Routes>
        </Router>
      </QueryClientProvider>
      <ToastContainer />
    </div>
  );
}

export default App;
