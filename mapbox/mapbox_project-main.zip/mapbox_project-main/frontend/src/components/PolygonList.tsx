import React from 'react';
import { Polygon } from '../types';
import PolygonListItem from '../components/PolygonListItem';

interface PolygonListProps {
  data: Polygon[] | undefined;
  isLoading: boolean;
}

const PolygonList: React.FC<PolygonListProps> = ({ data, isLoading }) => {
  return (
    <div className="mt-6">
      {isLoading && <div>...Loading</div>}
      <h2 className="text-center font-semibold text-2xl mt-6">Polygons:</h2>
      {data?.map((polygon) => (
        <PolygonListItem key={polygon.id} polygon={polygon} />
      ))}
    </div>
  );
};

export default PolygonList;
