import React from 'react';

import { UseFormHandleSubmit, UseFormRegister, FieldErrors } from 'react-hook-form';

interface PolygonFormProps {
  onSubmit: (data: { polygonTitle: string }) => void;
  handleSubmit: UseFormHandleSubmit<
    {
      polygonTitle: string;
    },
    undefined
  >;
  clearMap: () => void;
  register: UseFormRegister<{
    polygonTitle: string;
  }>;
  errors: FieldErrors<{
    polygonTitle: string;
  }>;
}

const PolygonForm: React.FC<PolygonFormProps> = ({
  onSubmit,
  handleSubmit,
  clearMap,
  register,
  errors
}) => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-md">
      <p className="text-gray-700 mb-4">Click the map to draw a polygon.</p>
      <form onSubmit={handleSubmit(onSubmit)}>
        <input
          className="border-slate-300 border-2 rounded-md w-full p-2 mb-4"
          type="text"
          {...register('polygonTitle')}
          placeholder="polygon name..."
        />
        {errors.polygonTitle && <p className="text-red-500 mb-4">{errors.polygonTitle.message}</p>}
        <div className="flex flex-col space-y-2">
          <button
            className="bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-700"
            type="submit"
          >
            Submit
          </button>
          <button
            className="bg-red-500 text-white py-2 px-4 rounded-md hover:bg-red-700"
            type="button"
            onClick={clearMap}
          >
            Reset
          </button>
        </div>
      </form>
    </div>
  );
};

export default PolygonForm;
