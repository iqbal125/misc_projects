import { Link } from 'react-router-dom';
import { Polygon } from '../types';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { deletePolygon } from '../api/polygon';
import { toast } from 'react-toastify';
interface PolygonItemProps {
  polygon: Polygon;
}

const PolygonListItem = ({ polygon }: PolygonItemProps) => {
  if (!polygon) {
    return <div>Item not found</div>;
  }

  const queryClient = useQueryClient();

  const mutation = useMutation({
    mutationFn: (id: string) => deletePolygon(id),
    onSuccess: () => {
      toast.success('Polygon Deleted');
      queryClient.invalidateQueries({ queryKey: ['polygons'] });
    },
    onError: (error: any) => {
      toast.error('Polygon Failed to Delete');
      console.error('Error Deleting polygon:', error);
    }
  });

  const handleDelete = () => {
    if (window.confirm('Are you sure you want to delete this polygon?')) {
      mutation.mutate(polygon.id);
    }
  };

  return (
    <div className="container mx-auto p-4">
      <div className="max-w-sm mx-auto bg-white rounded-lg shadow-md overflow-hidden w-64">
        <div className="p-4">
          <h1 className="text-2xl font-bold mb-2">{polygon.name}</h1>
        </div>
        <div className="flex justify-end p-4 space-x-2 border-t">
          <Link
            to={`/view/${polygon.id}`}
            className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-700"
          >
            View
          </Link>
          <Link
            to={`/edit/${polygon.id}`}
            className="bg-slate-500 text-white px-4 py-2 rounded hover:bg-slate-700"
          >
            Edit
          </Link>
          <button
            onClick={handleDelete}
            className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-700"
            disabled={mutation.isPending}
          >
            {mutation.isPending ? 'Deleting...' : 'Delete'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default PolygonListItem;
