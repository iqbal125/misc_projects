export const BASE_URL = 'https://uiwe2tmy3z.us-east-1.awsapprunner.com';

export const GenericErrorText = 'Something Went Wrong';
