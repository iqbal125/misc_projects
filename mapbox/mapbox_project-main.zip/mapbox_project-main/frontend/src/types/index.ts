export interface Polygon {
  id: string;
  name: string;
  coordinates: number[][];
  zoom: number;
  center: number[];
}
