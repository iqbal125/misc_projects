import { z } from 'zod';

export const schema = z.object({
  polygonTitle: z.string().min(3, 'Polygon name must be at least 3 characters long')
});

export type FormData = z.infer<typeof schema>;
