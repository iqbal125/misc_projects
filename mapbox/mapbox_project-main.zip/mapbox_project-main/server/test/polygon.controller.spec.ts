import { Test, TestingModule } from '@nestjs/testing';
import { MapController } from '../src/modules/map/map.controller';
import { MapService } from '../src/modules/map/map.service';
import { MapPolygon } from '@prisma/client';
import { CreatePolygonDto } from '../src/modules/map/dto/create.dto';

describe('MapController', () => {
  let mapController: MapController;
  let mapService: MapService;

  const mockPolygon: MapPolygon = {
    id: '1',
    name: 'Test Polygon',
    coordinates: [[-91.874, 42.76]],
    zoom: 6,
    center: [-91.874, 42.76],
  };

  const mockMapService = {
    getOnePolygon: jest.fn((id) => Promise.resolve(mockPolygon)),
    getPolygons: jest.fn(() => Promise.resolve([mockPolygon])),
    createPolygon: jest.fn((data) =>
      Promise.resolve({ ...mockPolygon, ...data }),
    ),
    updatePolygon: jest.fn((params) =>
      Promise.resolve({ ...mockPolygon, ...params.data }),
    ),
    deletePolygon: jest.fn(() => Promise.resolve(mockPolygon)),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [MapController],
      providers: [
        {
          provide: MapService,
          useValue: mockMapService,
        },
      ],
    }).compile();

    mapController = module.get<MapController>(MapController);
    mapService = module.get<MapService>(MapService);
  });

  it('should be defined', () => {
    expect(mapController).toBeDefined();
  });

  describe('getPolygonById', () => {
    it('should return a polygon by id', async () => {
      const result = await mapController.getPolygonById('1');
      expect(result).toEqual(mockPolygon);
      expect(mapService.getOnePolygon).toHaveBeenCalledWith({ id: '1' });
    });
  });

  describe('getPolygons', () => {
    it('should return an array of polygons', async () => {
      const result = await mapController.getPolygons();
      expect(result).toEqual([mockPolygon]);
      expect(mapService.getPolygons).toHaveBeenCalled();
    });
  });

  describe('deletePolygon', () => {
    it('should delete and return the polygon', async () => {
      const result = await mapController.deletePolygon('1');
      expect(result).toEqual(mockPolygon);
      expect(mapService.deletePolygon).toHaveBeenCalledWith({ id: '1' });
    });
  });
});
