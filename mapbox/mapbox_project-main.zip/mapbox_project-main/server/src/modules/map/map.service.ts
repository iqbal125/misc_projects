import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from 'nestjs-prisma';
import { MapPolygon, Prisma } from '@prisma/client';
import { plainToInstance } from 'class-transformer';
import { MapPolygonDto } from './dto/get-all.dto';
import { Logger } from '@nestjs/common';

@Injectable()
export class MapService {
  constructor(private prisma: PrismaService) {}

  async getOnePolygon(
    where: Prisma.MapPolygonWhereUniqueInput,
  ): Promise<MapPolygon> {
    const res = this.prisma.mapPolygon.findUnique({
      where,
    });

    return plainToInstance(MapPolygonDto, res);
  }

  async getPolygons(): Promise<MapPolygon[]> {
    const res = await this.prisma.mapPolygon.findMany();

    return plainToInstance(MapPolygonDto, res);
  }

  async createPolygon(data: Prisma.MapPolygonCreateInput): Promise<MapPolygon> {
    return this.prisma.mapPolygon.create({
      data,
    });
  }

  async updatePolygon(params: {
    where: Prisma.MapPolygonWhereUniqueInput;
    data: Prisma.MapPolygonUpdateInput;
  }): Promise<MapPolygon> {
    const { data, where } = params;
    return this.prisma.mapPolygon.update({
      data,
      where,
    });
  }

  async deletePolygon(
    where: Prisma.MapPolygonWhereUniqueInput,
  ): Promise<MapPolygon> {
    return this.prisma.mapPolygon.delete({
      where,
    });
  }
}
