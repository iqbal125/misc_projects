import {
  Controller,
  Get,
  Param,
  Post,
  Body,
  Put,
  Delete,
  ParseIntPipe,
} from '@nestjs/common';
import { CreatePolygonDto } from './dto/create.dto';

import { MapService } from './map.service';
import { MapPolygon, Prisma } from '@prisma/client';

@Controller()
export class MapController {
  constructor(private readonly MapService: MapService) {}

  @Get('polygon/:id')
  async getPolygonById(@Param('id') id: string): Promise<MapPolygon> {
    return this.MapService.getOnePolygon({ id });
  }

  @Get('all-polygons')
  async getPolygons(): Promise<MapPolygon[]> {
    return this.MapService.getPolygons();
  }

  @Post('polygon')
  async createPolygon(@Body() MapData: CreatePolygonDto): Promise<MapPolygon> {
    const { id, name, coordinates, zoom, center } = MapData;
    const coordinatesJson = JSON.stringify(coordinates);

    return this.MapService.createPolygon({
      id,
      name,
      coordinates: coordinatesJson,
      zoom,
      center,
    });
  }

  @Put('polygon')
  async updatePolygon(@Body() MapData: CreatePolygonDto) {
    const { id, name, coordinates, zoom, center } = MapData;
    const coordinatesJson = JSON.stringify(coordinates);

    return this.MapService.updatePolygon({
      where: { id },
      data: {
        name,
        coordinates: coordinatesJson,
        zoom,
        center,
      },
    });
  }

  @Delete('polygon/:id')
  async deletePolygon(@Param('id') id: string): Promise<MapPolygon> {
    return this.MapService.deletePolygon({ id });
  }
}
