import { Transform } from 'class-transformer';

export class MapPolygonDto {
  id: string;
  name: string;

  @Transform(({ value }) => JSON.parse(value))
  coordinates: number[][];

  zoom: number;
  center: number[];
}
