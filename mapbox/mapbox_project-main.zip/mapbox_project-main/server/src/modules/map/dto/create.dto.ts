import { ApiProperty } from '@nestjs/swagger';
import {
  IsArray,
  IsNotEmpty,
  IsNumber,
  IsString,
  MinLength,
  ValidateNested,
  ArrayMinSize,
  ArrayNotEmpty,
} from 'class-validator';

import { Type } from 'class-transformer';

class CoordinateDto {
  @IsArray()
  @ArrayMinSize(2)
  @ArrayNotEmpty()
  @IsNumber({}, { each: true })
  @ApiProperty({ type: [Number] })
  coordinate: number[];
}

export class CreatePolygonDto {
  @IsString()
  @IsNotEmpty()
  @ApiProperty()
  id: string;

  @IsString()
  @IsNotEmpty()
  @MinLength(3)
  @ApiProperty()
  name: string;

  @IsArray()
  //@ValidateNested({ each: true })
  @Type(() => CoordinateDto)
  @ArrayMinSize(1)
  @ArrayNotEmpty()
  @ApiProperty({ type: [[Number]] })
  coordinates: number[][];

  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  zoom: number;

  @IsArray()
  @ArrayNotEmpty()
  @ArrayMinSize(2)
  @IsNumber({}, { each: true })
  @ApiProperty({ type: [Number] })
  center: number[];
}
