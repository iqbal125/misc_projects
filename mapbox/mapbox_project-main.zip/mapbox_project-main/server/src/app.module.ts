import { Module } from '@nestjs/common';
import { HealthModule } from './modules/health/health.module';
import { MapModule } from './modules/map/map.module';
import { PrismaModule } from 'nestjs-prisma';
import { providePrismaClientExceptionFilter } from 'nestjs-prisma';

@Module({
  imports: [
    HealthModule,
    MapModule,
    PrismaModule.forRoot({
      isGlobal: true,
    }),
  ],
  controllers: [],
  providers: [providePrismaClientExceptionFilter()],
})
export class AppModule {}
