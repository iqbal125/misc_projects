export interface Instance {
  cloud: string;
  shade_instance_type: string;
  cloud_instance_type: string;
  configuration: InstanceConfiguration;
  memory_in_gb: number;
  storage_in_gb: number;
  vcpus: number;
  num_gpus: number;
  gpu_type: string;
  interconnect: string;
  nvlink: boolean;
  hourly_price: number;
  availability: Availability[];
}

export interface InstanceConfiguration {
  memory_in_gb: number;
  storage_in_gb: number;
  vcpus: number;
  num_gpus: number;
  gpu_type: string;
  interconnect: string;
  nvlink: boolean;
  os_options: string[];
  vram_per_gpu_in_gb: number;
}

export interface Availability {
  region: string;
  available: boolean;
}

export interface TransformedInstanceList {
  gpu_type: string;
  instances: Instance[];
}
