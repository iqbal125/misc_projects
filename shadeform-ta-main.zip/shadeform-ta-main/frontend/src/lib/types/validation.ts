import { z } from 'zod';

export const createInstanceSchema = z.object({
  name: z.string().min(2, { message: 'Name is required' }),
  cloud: z.string(),
  shade_cloud: z.boolean().optional(),
  region: z.string({ message: 'Region Required' }),
  gpu_type: z.string(),
  configuration: z.string(),
  launch_configuration: z.string(),
  container_image: z.string(),
  os_options: z.string(),
  startup_script: z.string()
});

export type CreateInstanceT = z.infer<typeof createInstanceSchema>;
