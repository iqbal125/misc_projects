'use client';
import { useQuery } from '@tanstack/react-query';
import axios from 'axios';
import { useState } from 'react';

import { map, groupBy } from 'lodash';
import LaunchConfigForm from './_PageSections/LaunchConfigForm';
import CloudDisplayCard from './_PageSections/CloudDisplayCard';
import GPUDisplayCard from './_PageSections/GpuDisplayCard';

import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious
} from '@/components/ui/carousel';
import { Instance, TransformedInstanceList } from '@/lib/types/instances';

const Home: React.FC = () => {
  const [activeInstance, setActiveInstance] = useState<TransformedInstanceList>({
    gpu_type: '',
    instances: []
  });
  const [activeConfig, setActiveConfig] = useState<Instance | null>(null);
  const [selectedNumGPUs, setSelectedNumGPUs] = useState<number | null>(null);

  const queryFn = async () => {
    const res = await axios.get('http://localhost:3001/instances/types');

    const instances: Instance[] = res?.data?.instance_types;
    const result: TransformedInstanceList[] = map(
      groupBy(instances, 'gpu_type'),
      (instances, gpu_type) => ({
        instances,
        gpu_type
      })
    );
    return result;
  };

  const { isPending, isFetching, isLoading, error, data } = useQuery({
    queryKey: ['instanceData'],
    queryFn,
    placeholderData: []
  });

  return (
    <main className="m-6">
      <h2 className="text-center font-semibold text-xl">Select GPU Below to get Started</h2>
      {(isPending || isLoading || isFetching) && <div>Loading...</div>}
      {error && <div>An error Occured...</div>}

      <div className="flex justify-center">
        <Carousel className="w-4/5">
          <CarouselContent>
            {!isFetching &&
              data?.map((instance_type: TransformedInstanceList) => (
                <CarouselItem
                  key={instance_type.gpu_type}
                  className="md:basis-1/2 xl:basis-1/3 2xl:basis-1/4"
                >
                  <div className="m-10">
                    <GPUDisplayCard
                      setActiveInstance={setActiveInstance}
                      setSelectedNumGPUs={setSelectedNumGPUs}
                      instance_type={instance_type}
                      activeInstance={activeInstance}
                      selectedNumGPUs={selectedNumGPUs}
                    />
                  </div>
                </CarouselItem>
              ))}
          </CarouselContent>
          {data && (
            <div>
              <CarouselPrevious />
              <CarouselNext />
            </div>
          )}
        </Carousel>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 2xl:grid-cols-5 border p-3 rounded-xl">
        {selectedNumGPUs &&
          activeInstance?.instances
            .filter((instance: Instance) => instance.num_gpus === selectedNumGPUs)
            .map((instance) => (
              <div key={`${instance.cloud}-${instance.cloud_instance_type}`}>
                <CloudDisplayCard
                  instance={instance}
                  activeConfig={activeConfig}
                  setActiveConfig={setActiveConfig}
                />
              </div>
            ))}
      </div>

      <div className="flex justify-center">
        {activeConfig && <LaunchConfigForm activeConfig={activeConfig} />}
      </div>
    </main>
  );
};

export default Home;
