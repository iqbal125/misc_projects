import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useEffect, useState } from 'react';
import { Availability, Instance } from '@/lib/types/instances';
import { Dispatch, SetStateAction } from 'react';

interface CloudDisplayprops {
  instance: Instance;
  setActiveConfig: Dispatch<SetStateAction<Instance | null>>;
  activeConfig: Instance | null;
}

const CloudDisplayCard = ({ instance, setActiveConfig, activeConfig }: CloudDisplayprops) => {
  const [noneAvailable, setNoneAvailable] = useState(false);

  const {
    gpu_type,
    cloud,
    num_gpus,
    hourly_price,
    shade_instance_type,
    availability,
    memory_in_gb,
    vcpus,
    storage_in_gb,
    nvlink
  } = instance;

  const isAnyRegionAvailable = (availability: Availability[]) => {
    const isAvailable = availability.some((region: Availability) => region.available);
    if (!isAvailable) setNoneAvailable(true);
  };

  useEffect(() => {
    isAnyRegionAvailable(availability);
  }, [activeConfig]);

  function countAvailableRegions(regions: Availability[]) {
    const availableRegions = regions.filter((region) => region.available);
    return availableRegions.length;
  }

  return (
    <div
      onClick={() => {
        if (!noneAvailable) setActiveConfig(instance);
      }}
      className={`${noneAvailable ? 'cursor-not-allowed' : ''}`}
    >
      <Tabs
        defaultValue="gpu"
        className="min-w-[300px] min-h-[300px] m-2 rounded-lg border bg-card text-card-foreground shadow-sm"
      >
        <div className="item-center w-full justify-center	flex p-2 border-b-[1px]">
          <TabsList className="grid w-[45%] grid-cols-2">
            <TabsTrigger value="gpu">GPU</TabsTrigger>
            <TabsTrigger value="specs">Specs</TabsTrigger>
          </TabsList>
        </div>
        <TabsContent value="gpu" className="mt-0">
          <Card
            className={`min-h-[228px] border-none shadow-none cursor-pointer ${
              noneAvailable ? 'cursor-not-allowed' : ''
            }`}
          >
            <CardHeader className="py-4">
              <CardTitle>
                <div className="flex justify-between items-center">
                  <div>
                    <p>{cloud}</p>
                  </div>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between">
                <p>Price/hr</p>
                <p className="font-bold">${hourly_price}</p>
              </div>
              <div className="flex justify-between">
                <p>Instance Type</p>
                <p className="font-bold">{shade_instance_type}</p>
              </div>
              <div className="flex justify-between">
                <p>GPU Type</p>
                <p className="font-bold">{gpu_type}</p>
              </div>
              <div className={`flex justify-between`}>
                <p>Availability</p>
                {noneAvailable ? (
                  <div className="text-red-300">None available</div>
                ) : (
                  <p className="font-bold">{countAvailableRegions(availability)} Regions</p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="specs">
          <Card className="min-h-[220px] border-none shadow-none">
            <CardContent className="space-y-4">
              <div className="flex justify-between">
                <p>Total VRAM</p>
                <p className="font-bold">{memory_in_gb} GB</p>
              </div>
              <div className="flex justify-between">
                <p>VCPU</p>
                <p className="font-bold">{vcpus}</p>
              </div>
              <div className="flex justify-between">
                <p>Storage</p>
                <p className="font-bold">{storage_in_gb} GB</p>
              </div>
              <div className="flex justify-between">
                <p>NVLink</p>
                <p className="font-bold">{nvlink ? 'Supported' : 'Not Supported'}</p>
              </div>
              <div className="flex justify-between">
                <p>GPU Interconnect</p>
                <p className="font-bold">{instance.configuration.interconnect}</p>
              </div>
              <div className="flex justify-between">
                <p>No Of GPU</p>
                <p className="font-bold">{num_gpus}</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default CloudDisplayCard;
