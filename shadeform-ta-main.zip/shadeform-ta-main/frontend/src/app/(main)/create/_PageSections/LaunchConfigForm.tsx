import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { createInstanceSchema, CreateInstanceT } from '@/lib/types/validation';
import { Instance } from '@/lib/types/instances';
import { Button } from '@/components/ui/button';
import axios from 'axios';
import { toast } from 'react-toastify';
interface CreateFormI {
  activeConfig: Instance;
}

const LaunchConfigForm = ({ activeConfig }: CreateFormI) => {
  const form = useForm<CreateInstanceT>({
    resolver: zodResolver(createInstanceSchema),
    defaultValues: {
      name: '',
      cloud: '',
      region: undefined,
      gpu_type: '',
      configuration: '',
      launch_configuration: '',
      os_options: undefined,
      container_image: '',
      startup_script: ''
    }
  });

  const {
    cloud,
    shade_instance_type,
    configuration,
    memory_in_gb,
    storage_in_gb,
    vcpus,
    num_gpus,
    gpu_type,
    nvlink,
    hourly_price,
    availability
  } = activeConfig;

  const onSubmit = async (data: CreateInstanceT) => {
    const { name, region, os_options, container_image, startup_script } = data;
    const { shade_cloud = false } = data;

    const errorText = 'Both Container and VM options Cant be selected';

    if (startup_script && container_image) {
      form.setError('container_image', {
        message: errorText
      });
      form.setError('startup_script', {
        message: errorText
      });
      throw new Error(errorText);
    }
    let launchConfig;

    if (startup_script) {
      launchConfig = {
        type: 'script',
        script_configuration: {
          base64_script: startup_script
        }
      };
    } else {
      launchConfig = {
        type: 'docker',
        docker_configuration: {
          image: container_image
        }
      };
    }

    const dataPost = {
      name,
      cloud,
      region,
      shade_instance_type,
      shade_cloud,
      launch_configuration: JSON.stringify(launchConfig),
      os: os_options
    };

    try {
      await axios.post('http://localhost:3001/instances/create', dataPost);
    } catch (e) {
      form.setError('name', { message: 'An Error Occured' });
    }

    toast.success('Instance Created');
  };

  return (
    <Card className="w-[680px] mt-10">
      <CardHeader>
        <CardTitle>GPU Instance Configuration</CardTitle>
      </CardHeader>
      <CardContent className="grid grid-cols-2 gap-12">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="gap-4 flex flex-col">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Machine Name</FormLabel>
                  <FormControl>
                    <Input {...form.register('name')} placeholder="name" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="region"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Region</FormLabel>

                  <Select
                    value={field.value}
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger className="w-[220px]">
                        <SelectValue placeholder="Region" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {availability.map((item) => {
                        const { region, available } = item;

                        if (available) {
                          return (
                            <SelectItem key={region} value={region}>
                              {region}
                            </SelectItem>
                          );
                        }
                      })}
                    </SelectContent>
                  </Select>

                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="shade_cloud"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>ShadeCloud</FormLabel>
                  <FormControl>
                    <div>
                      <Switch
                        defaultChecked={false}
                        value={String(form.watch('shade_cloud'))}
                        checked={form.watch('shade_cloud')}
                        onCheckedChange={field.onChange}
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="os_options"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>OS Options</FormLabel>

                  <Select value={field.value} onValueChange={field.onChange}>
                    <FormControl>
                      <SelectTrigger {...form.register('container_image')} className="w-[220px]">
                        <SelectValue placeholder="OS Options" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {configuration.os_options.map((item) => (
                        <SelectItem key={item} value={item}>
                          {item}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormLabel>Launch Configurations</FormLabel>
            <Tabs defaultValue="vm">
              <TabsList className="grid grid-cols-2">
                <TabsTrigger value="vm">VM</TabsTrigger>
                <TabsTrigger value="container">Container</TabsTrigger>
              </TabsList>
              <TabsContent value="vm" className="mt-0">
                <FormField
                  control={form.control}
                  name="startup_script"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Startup Script</FormLabel>
                      <FormControl>
                        <Input
                          {...form.register('startup_script')}
                          placeholder="script"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </TabsContent>
              <TabsContent value="container" className="mt-0">
                <FormField
                  control={form.control}
                  name="container_image"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Container Image</FormLabel>
                      <FormControl>
                        <Input
                          {...form.register('container_image')}
                          placeholder="image"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </TabsContent>
            </Tabs>
            <Button className="mt-8" type="submit">
              Launch
            </Button>
          </form>
        </Form>
        <div className="space-y-2 mt-4">
          <p>GPU Type: {gpu_type}</p>
          <p>Cloud: {cloud}</p>
          <p>Number of GPUs: {num_gpus}</p>
          <p>Hourly Price: ${hourly_price}</p>
          <p>Instance Type: {shade_instance_type}</p>
          <p>Availability: {availability.length} Regions</p>
          <p>Memory: {memory_in_gb} GB</p>
          <p>vCPUs: {vcpus}</p>
          <p>Storage: {storage_in_gb} GB</p>
          <p>NVLink: {nvlink ? 'Supported' : 'Not Supported'}</p>
        </div>
      </CardContent>
    </Card>
  );
};

export default LaunchConfigForm;
