import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';

import { Instance, TransformedInstanceList } from '@/lib/types/instances';
import { Dispatch, SetStateAction } from 'react';

type GPUKey = 1 | 2 | 4 | 8;

type GPUAvailability = {
  1: boolean;
  2: boolean;
  4: boolean;
  8: boolean;
};

interface GPUDisplayCardProps {
  instance_type: TransformedInstanceList;
  activeInstance: TransformedInstanceList;
  setSelectedNumGPUs: Dispatch<SetStateAction<number | null>>;
  setActiveInstance: Dispatch<SetStateAction<TransformedInstanceList>>;
  selectedNumGPUs: number | null;
}

const GPUDisplayCard = ({
  instance_type,
  activeInstance,
  setSelectedNumGPUs,
  setActiveInstance,
  selectedNumGPUs
}: GPUDisplayCardProps) => {
  const [availableGpus, setGPUs] = useState<GPUAvailability>({
    1: false,
    2: false,
    4: false,
    8: false
  });
  const [noneAvailable, setNoneAvailable] = useState(false);
  const [bestPrice, setBestPrice] = useState(Number.POSITIVE_INFINITY);

  const { gpu_type, instances } = instance_type;

  useEffect(() => {
    instances?.forEach((instance: Instance) => {
      if (instance.hourly_price < bestPrice) {
        setBestPrice(instance.hourly_price);
      }
    });

    let gpuAvailability = { 1: false, 2: false, 4: false, 8: false };

    instances?.forEach((instance: Instance) => {
      if (instance.num_gpus && instance.availability.some((region) => region.available)) {
        gpuAvailability[instance.num_gpus as GPUKey] = true;
      }
    });

    if (Object.values(gpuAvailability).every((i) => i === false)) setNoneAvailable(true);
    setGPUs(gpuAvailability);
  }, []);

  const isActiveInstance = gpu_type === activeInstance?.gpu_type;

  const handleNumGPUsClick = (num_gpus: number) => {
    setSelectedNumGPUs(num_gpus);
    setActiveInstance(instance_type);
  };

  return (
    <div>
      <Card className={`min-w-64 ${isActiveInstance ? 'bg-slate-300' : ''} `}>
        <CardHeader>
          <div>{gpu_type}</div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between mt-4">
              <span>Type</span>
              <p className="">{gpu_type}</p>
            </div>
            <hr />

            <div className="flex justify-between">
              <p className="text-md">Available Price</p>
              <p className="text-md">{instances?.[0]?.hourly_price}</p>
            </div>

            <div className="flex justify-between">
              <p className="text-md">Best Price</p>
              <p className="text-md">{bestPrice}</p>
            </div>
          </div>

          <div className="flex flex-col mt-4">
            <p className="mb-2">Select Number of GPUs:</p>

            <div className="flex justify-between mt-1">
              {Object.keys(availableGpus).map((numGPUs) => {
                let numGPU = Number(numGPUs) as GPUKey;
                if (availableGpus[numGPU]) {
                  return (
                    <button
                      key={numGPUs}
                      className={`w-1/8 text-center border border-1 p-4 ${
                        selectedNumGPUs === numGPU && isActiveInstance ? 'bg-blue-100' : ''
                      }`}
                      onClick={() => handleNumGPUsClick(numGPU)}
                    >
                      {numGPUs}
                    </button>
                  );
                }
                return null;
              })}
              {noneAvailable && <div className="text-red-300">Not Available</div>}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default GPUDisplayCard;
