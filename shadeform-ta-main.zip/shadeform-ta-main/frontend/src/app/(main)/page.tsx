'use client';
import { useQuery } from '@tanstack/react-query';
import axios from 'axios';
import { useState, useEffect } from 'react';

import { DataTable } from '@/components/DataTable';
import { type TableDataT, type Instance, columns } from '@/lib/config/TablesCols';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useRouter } from 'next/navigation';
import { toast } from 'react-toastify';

export default function Home() {
  const [tableData, setTableData] = useState<TableDataT[]>([]);
  const [activeInstanceId, setActiveInstanceId] = useState('');
  const router = useRouter();

  const { error, data = [] } = useQuery<Instance[]>({
    queryKey: ['instanceData'],
    queryFn: () => axios.get('http://localhost:3001/instances').then((res) => res.data)
  });

  useEffect(() => {
    const tableRows: TableDataT[] = data.map((item) => ({
      id: item.id,
      name: item.name,
      gpu_type: item.shade_instance_type,
      cloud: item.cloud,
      status: item.status
    }));

    setTableData(tableRows);
  }, [data]);

  const activeInstance = data.find((item) => item.id === activeInstanceId);

  const handleDelete = async (idToDelete: string) => {
    try {
      await axios.post(`http://localhost:3001/instance/${idToDelete}/delete`);
    } catch (error) {
      console.error(`Error deleting instance with ID ${idToDelete}:`, error);
      throw new Error('an error occured');
    }

    toast.success('Instance Deleted');
    router.push('/create');
  };

  return (
    <main className="flex flex-col items-center justify-between my-10">
      <DataTable columns={columns} data={tableData} setActiveInstanceId={setActiveInstanceId} />
      {error && <div>An error Occurred</div>}
      {activeInstance && (
        <Card className={`mt-10 break-words text-xs py-2 leading-9 bg-slate-100 sm:w-400px`}>
          <CardContent>
            <div className="flex justify-between">
              Name <strong>{activeInstance.name}</strong>
            </div>
            <div className="flex justify-between">
              Region <strong>{activeInstance.region}</strong>
            </div>
            <div>
              {activeInstance.shade_cloud ? (
                <div className="flex justify-between">
                  Shade Cloud&nbsp;
                  <p>
                    <strong>Enabled</strong>
                  </p>
                </div>
              ) : (
                <div className="flex justify-between">
                  Shade Cloud&nbsp;
                  <p>
                    <strong>Disabled</strong>
                  </p>
                </div>
              )}
            </div>
            <div className="flex justify-between mb-3">
              Cloud <strong>{activeInstance.cloud}</strong>
            </div>
            <hr className="md:hidden" />
            <div className="flex justify-between mt-3">
              Status <strong>{activeInstance.status}</strong>
            </div>
            <div className="flex justify-between">
              GPU Type <strong>{activeInstance.shade_instance_type}</strong>
            </div>
            <div className="flex justify-between">
              Memory <strong>{JSON.parse(activeInstance.configuration).memory_in_gb}GB</strong>
            </div>
            <div className="flex justify-between">
              Storage <strong>{JSON.parse(activeInstance.configuration).storage_in_gb}GB</strong>
            </div>
            <div className="flex justify-between mb-3">
              GPUs <strong className="ml-1">{activeInstance.cloud_instance_type}</strong>
            </div>
            <hr className="md:hidden" />
            <div className="flex justify-between mt-3">
              Interconnect <strong>{JSON.parse(activeInstance.configuration).interconnect}</strong>
            </div>
            <div className="flex justify-between mt-3">
              Launch Type: <strong>{JSON.parse(activeInstance.launch_configuration).type}</strong>
            </div>
            <div className="flex justify-between">
              Hourly Price <strong>${activeInstance.hourly_price}</strong>
            </div>
            <Button
              className="mt-4"
              variant="destructive"
              onClick={() => handleDelete(activeInstance.id)}
            >
              Delete
            </Button>
          </CardContent>
        </Card>
      )}
    </main>
  );
}
