import {
  ColumnDef,
  flexRender,
  getCoreRowModel,
  useReactTable,
  getPaginationRowModel
} from '@tanstack/react-table';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Dispatch, SetStateAction, useState } from 'react';

interface DataTableProps<TData, TValue> {
  columns: ColumnDef<TData, TValue>[];
  data: TData[];
  setActiveInstanceId: Dispatch<SetStateAction<string>>;
}

export function DataTable<TData, TValue>({
  columns,
  data,
  setActiveInstanceId
}: DataTableProps<TData, TValue>) {
  const [pageIndex, setPageIndex] = useState(0);

  const table = useReactTable({
    data,
    columns,
    state: {
      pagination: {
        pageIndex,
        pageSize: 10
      }
    },
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel()
  });

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          {table.getHeaderGroups().map((headerGroup) => (
            <TableRow key={headerGroup.id}>
              {headerGroup.headers.map((header) => (
                <TableHead key={header.id}>
                  {header.isPlaceholder
                    ? null
                    : flexRender(header.column.columnDef.header, header.getContext())}
                </TableHead>
              ))}
            </TableRow>
          ))}
        </TableHeader>
        <TableBody>
          {table.getRowModel().rows.length > 0 ? (
            table.getRowModel().rows.map((row) => (
              <TableRow
                className="cursor-pointer"
                key={row.id}
                data-state={row.getIsSelected() && 'selected'}
                onClick={() => setActiveInstanceId(row.getValue('id'))}
              >
                {row.getVisibleCells().map((cell) => (
                  <TableCell key={cell.id}>
                    {flexRender(cell.column.columnDef.cell, cell.getContext())}
                  </TableCell>
                ))}
              </TableRow>
            ))
          ) : (
            <TableRow>
              <TableCell colSpan={columns.length + 1} className="h-24 text-center">
                No results.
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
      <div className="flex items-center justify-between p-4">
        <div>
          <button
            className="text-xs md:text-sm bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-l"
            onClick={() => setPageIndex(0)}
            disabled={pageIndex === 0}
          >
            First
          </button>
          <button
            className="text-xs md:text-sm bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4"
            onClick={() => setPageIndex((old) => Math.max(old - 1, 0))}
            disabled={pageIndex === 0}
          >
            Previous
          </button>
          <button
            className="text-xs md:text-sm bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4"
            onClick={() => setPageIndex((old) => (old + 1 < table.getPageCount() ? old + 1 : old))}
            disabled={pageIndex === table.getPageCount() - 1}
          >
            Next
          </button>
          <button
            className="text-xs md:text-sm bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-r"
            onClick={() => setPageIndex(table.getPageCount() - 1)}
            disabled={pageIndex === table.getPageCount() - 1}
          >
            Last
          </button>
        </div>
        {table.getPageCount() !== 0 && (
          <span className="text-xs md:text-sm px-2 py-1">
            Page {pageIndex + 1} of {table.getPageCount()}
          </span>
        )}
      </div>
    </div>
  );
}
