import { useState } from 'react';
import { Button } from './Button';
import { Input, Textarea } from './Input';
import type { CreateTodo } from '../types/types';

interface TodoFormProps {
    onSubmit: (data: CreateTodo) => void;
    isLoading?: boolean;
}

export const TodoForm: React.FC<TodoFormProps> = ({
    onSubmit,
    isLoading = false
}) => {
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [errors, setErrors] = useState<{ title?: string; description?: string }>({});

    const validate = () => {
        const newErrors: { title?: string; description?: string } = {};

        if (!title.trim()) {
            newErrors.title = 'Title is required';
        } else if (title.length > 100) {
            newErrors.title = 'Title too long';
        }

        if (!description.trim()) {
            newErrors.description = 'Description is required';
        } else if (description.length > 500) {
            newErrors.description = 'Description too long';
        }

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();

        if (!validate()) {
            return;
        }

        onSubmit({
            title: title.trim(),
            description: description.trim(),
        });

        // Reset form
        setTitle('');
        setDescription('');
        setErrors({});
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4 p-4 border rounded-lg bg-card">
            <h2 className="text-xl font-semibold">Add New Todo</h2>

            <Input
                label="Title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                error={errors.title}
                placeholder="Enter todo title"
                disabled={isLoading}
            />

            <Textarea
                label="Description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                error={errors.description}
                placeholder="Enter todo description"
                disabled={isLoading}
                rows={3}
            />

            <Button
                type="submit"
                disabled={isLoading}
            >
                {isLoading ? 'Adding...' : 'Add Todo'}
            </Button>
        </form>
    );
};
