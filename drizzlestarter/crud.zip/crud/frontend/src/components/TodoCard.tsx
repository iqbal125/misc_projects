import { useState } from 'react';
import { Button } from './Button';
import { Input, Textarea } from './Input';
import type { Todo, UpdateTodo } from '../types/types';

interface TodoCardProps {
    todo: Todo;
    onUpdate: (id: number, data: UpdateTodo) => void;
    onDelete: (id: number) => void;
    isLoading?: boolean;
}

export const TodoCard: React.FC<TodoCardProps> = ({
    todo,
    onUpdate,
    onDelete,
    isLoading = false
}) => {
    const [isEditing, setIsEditing] = useState(false);
    const [title, setTitle] = useState(todo.title);
    const [description, setDescription] = useState(todo.description);

    const handleUpdate = () => {
        if (title.trim() && description.trim()) {
            onUpdate(todo.id, {
                title: title.trim(),
                description: description.trim(),
            });
            setIsEditing(false);
        }
    };

    const handleCancel = () => {
        setTitle(todo.title);
        setDescription(todo.description);
        setIsEditing(false);
    };

    if (isEditing) {
        return (
            <div className="p-4 border rounded-lg bg-card space-y-3">
                <Input
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="Todo title"
                    disabled={isLoading}
                />
                <Textarea
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Todo description"
                    disabled={isLoading}
                    rows={3}
                />
                <div className="flex gap-2">
                    <Button
                        size="sm"
                        onClick={handleUpdate}
                        disabled={isLoading || !title.trim() || !description.trim()}
                    >
                        Save
                    </Button>
                    <Button
                        size="sm"
                        variant="secondary"
                        onClick={handleCancel}
                        disabled={isLoading}
                    >
                        Cancel
                    </Button>
                </div>
            </div>
        );
    }

    return (
        <div className="p-4 border rounded-lg bg-card">
            <h3 className="font-semibold text-lg mb-2">{todo.title}</h3>
            <p className="text-muted-foreground mb-4">{todo.description}</p>
            <div className="flex gap-2">
                <Button
                    size="sm"
                    variant="secondary"
                    onClick={() => setIsEditing(true)}
                    disabled={isLoading}
                >
                    Edit
                </Button>
                <Button
                    size="sm"
                    variant="danger"
                    onClick={() => onDelete(todo.id)}
                    disabled={isLoading}
                >
                    Delete
                </Button>
            </div>
        </div>
    );
};
