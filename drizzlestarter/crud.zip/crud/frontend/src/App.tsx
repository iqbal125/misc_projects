import { useState, useEffect } from 'react';
import { TodoForm } from './components/TodoForm';
import { TodoCard } from './components/TodoCard';
import { getAllTodos, createTodo, updateTodo, deleteTodo } from './api/todos';
import type { Todo, CreateTodo, UpdateTodo } from './types/types';
import "./styles/index.css";

function App() {
  const [todos, setTodos] = useState<Todo[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadTodos();
  }, []);

  const loadTodos = async () => {
    try {
      setLoading(true);
      setError(null);
      const todoList = await getAllTodos();
      setTodos(todoList);
    } catch (err) {
      setError('Failed to load todos');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateTodo = async (todoData: CreateTodo) => {
    try {
      setLoading(true);
      setError(null);
      const newTodo = await createTodo(todoData);
      setTodos(prev => [newTodo, ...prev]);
    } catch (err) {
      setError('Failed to create todo');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateTodo = async (id: number, updates: UpdateTodo) => {
    try {
      setError(null);
      const updatedTodo = await updateTodo(id, updates);
      setTodos(prev => prev.map(todo =>
        todo.id === id ? updatedTodo : todo
      ));
    } catch (err) {
      setError('Failed to update todo');
      console.error(err);
    }
  };

  const handleDeleteTodo = async (id: number) => {
    try {
      setError(null);
      await deleteTodo(id);
      setTodos(prev => prev.filter(todo => todo.id !== id));
    } catch (err) {
      setError('Failed to delete todo');
      console.error(err);
    }
  };

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <header className="text-center">
          <h1 className="text-3xl font-bold text-foreground">Todo App</h1>
          <p className="text-muted-foreground mt-2">Manage your tasks efficiently</p>
        </header>

        {error && (
          <div className="bg-destructive/10 border border-destructive text-destructive px-4 py-3 rounded">
            {error}
          </div>
        )}

        <TodoForm onSubmit={handleCreateTodo} isLoading={loading} />

        <div className="space-y-4">
          <h2 className="text-2xl font-semibold">
            Your Todos ({todos.length})
          </h2>

          {loading && todos.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              Loading todos...
            </div>
          ) : todos.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No todos yet. Create your first todo above!
            </div>
          ) : (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {todos.map(todo => (
                <TodoCard
                  key={todo.id}
                  todo={todo}
                  onUpdate={handleUpdateTodo}
                  onDelete={handleDeleteTodo}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;
