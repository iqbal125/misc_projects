import axios from "axios";
import type { Todo, CreateTodo, UpdateTodo } from "../types/types";

const api = axios.create({
  baseURL: "http://localhost:3000/api",
  headers: {
    "Content-Type": "application/json",
  },
});

export const getAllTodos = async (): Promise<Todo[]> => {
  const response = await api.get("/todos");
  return response.data.data;
};

export const getTodoById = async (id: number): Promise<Todo> => {
  const response = await api.get(`/todos/${id}`);
  return response.data.data;
};

export const createTodo = async (todo: CreateTodo): Promise<Todo> => {
  const response = await api.post("/todos", todo);
  return response.data.data;
};

export const updateTodo = async (
  id: number,
  updates: UpdateTodo
): Promise<Todo> => {
  const response = await api.put(`/todos/${id}`, updates);
  return response.data.data;
};

export const deleteTodo = async (id: number): Promise<void> => {
  await api.delete(`/todos/${id}`);
};
