export interface Todo {
  id: number;
  title: string;
  description: string;
}

export interface CreateTodo {
  title: string;
  description: string;
}

export interface UpdateTodo {
  title?: string;
  description?: string;
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}
