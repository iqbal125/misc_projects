import Database from "better-sqlite3";
import { drizzle } from "drizzle-orm/better-sqlite3";
import { migrate } from "drizzle-orm/better-sqlite3/migrator";
import * as schema from "./schema.js";

const sqlite = new Database("sqlite.db");
export const db = drizzle(sqlite, { schema });

// Run migrations on startup
try {
  migrate(db, { migrationsFolder: "drizzle" });
  console.log("Database migrations completed");
} catch (error) {
  console.log("No migrations to run or migration failed:", error);
}
