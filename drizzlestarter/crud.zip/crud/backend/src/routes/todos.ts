import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { eq } from "drizzle-orm";
import { db } from "../db/index.js";
import { todos } from "../db/schema.js";
import {
  createTodoSchema,
  updateTodoSchema,
  todoParamsSchema,
} from "../validation.js";

const todoRoutes = new Hono();

// GET /todos - Get all todos
todoRoutes.get("/", async (c) => {
  try {
    const allTodos = await db.select().from(todos);
    return c.json({
      success: true,
      data: allTodos,
    });
  } catch (error) {
    return c.json(
      {
        success: false,
        error: "Failed to fetch todos",
      },
      500
    );
  }
});

// GET /todos/:id - Get a specific todo
todoRoutes.get("/:id", zValidator("param", todoParamsSchema), async (c) => {
  try {
    const { id } = c.req.valid("param");
    const todo = await db.select().from(todos).where(eq(todos.id, id));

    if (todo.length === 0) {
      return c.json(
        {
          success: false,
          error: "Todo not found",
        },
        404
      );
    }

    return c.json({
      success: true,
      data: todo[0],
    });
  } catch (error) {
    return c.json(
      {
        success: false,
        error: "Failed to fetch todo",
      },
      500
    );
  }
});

// POST /todos - Create a new todo
todoRoutes.post("/", zValidator("json", createTodoSchema), async (c) => {
  try {
    const { title, description } = c.req.valid("json");

    const newTodo = await db
      .insert(todos)
      .values({
        title,
        description,
      })
      .returning();

    return c.json(
      {
        success: true,
        data: newTodo[0],
      },
      201
    );
  } catch (error) {
    return c.json(
      {
        success: false,
        error: "Failed to create todo",
      },
      500
    );
  }
});

// PUT /todos/:id - Update a todo
todoRoutes.put(
  "/:id",
  zValidator("param", todoParamsSchema),
  zValidator("json", updateTodoSchema),
  async (c) => {
    try {
      const { id } = c.req.valid("param");
      const updates = c.req.valid("json");

      // Check if todo exists
      const existingTodo = await db
        .select()
        .from(todos)
        .where(eq(todos.id, id));
      if (existingTodo.length === 0) {
        return c.json(
          {
            success: false,
            error: "Todo not found",
          },
          404
        );
      }

      const updatedTodo = await db
        .update(todos)
        .set({
          ...updates,
        })
        .where(eq(todos.id, id))
        .returning();

      return c.json({
        success: true,
        data: updatedTodo[0],
      });
    } catch (error) {
      return c.json(
        {
          success: false,
          error: "Failed to update todo",
        },
        500
      );
    }
  }
);

// DELETE /todos/:id - Delete a todo
todoRoutes.delete("/:id", zValidator("param", todoParamsSchema), async (c) => {
  try {
    const { id } = c.req.valid("param");

    // Check if todo exists
    const existingTodo = await db.select().from(todos).where(eq(todos.id, id));
    if (existingTodo.length === 0) {
      return c.json(
        {
          success: false,
          error: "Todo not found",
        },
        404
      );
    }

    await db.delete(todos).where(eq(todos.id, id));

    return c.json({
      success: true,
      message: "Todo deleted successfully",
    });
  } catch (error) {
    return c.json(
      {
        success: false,
        error: "Failed to delete todo",
      },
      500
    );
  }
});

export { todoRoutes };
