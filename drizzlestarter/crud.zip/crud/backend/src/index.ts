import { serve } from "@hono/node-server";
import { Hono } from "hono";
import { cors } from "hono/cors";
import { todoRoutes } from "./routes/todos.js";

const app = new Hono();

app.use(
  "/*",
  cors({
    origin: ["http://localhost:5173", "http://localhost:3000"],
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  })
);

app.get("/", (c) => {
  return c.json({
    message: "Todo API Server",
    version: "1.0.0",
    endpoints: {
      "GET /api/todos": "Get all todos",
      "GET /api/todos/:id": "Get a specific todo",
      "POST /api/todos": "Create a new todo",
      "PUT /api/todos/:id": "Update a todo",
      "DELETE /api/todos/:id": "Delete a todo",
    },
  });
});

// Mount todo routes
app.route("/api/todos", todoRoutes);

serve(
  {
    fetch: app.fetch,
    port: 3000,
  },
  (info) => {
    console.log(`Server is running on http://localhost:${info.port}`);
  }
);
