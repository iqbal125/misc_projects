# Todo API Backend

A simple CRUD API for managing todos built with Hono, Drizzle ORM, and SQLite.

## Features

- ✅ Create, Read, Update, Delete todos
- 🔒 Input validation with Zod
- 🗃️ SQLite database with Drizzle ORM
- 🚀 Fast performance with Hono
- 🔄 CORS enabled for frontend integration

## API Endpoints

### Base URL: `http://localhost:3000`

| Method | Endpoint         | Description         |
| ------ | ---------------- | ------------------- |
| GET    | `/`              | API information     |
| GET    | `/api/todos`     | Get all todos       |
| GET    | `/api/todos/:id` | Get a specific todo |
| POST   | `/api/todos`     | Create a new todo   |
| PUT    | `/api/todos/:id` | Update a todo       |
| DELETE | `/api/todos/:id` | Delete a todo       |

### Todo Object Structure

```json
{
  "id": 1,
  "title": "Sample Todo",
  "description": "This is a sample todo description"
}
```

### Request Examples

#### Create a Todo

```bash
curl -X POST http://localhost:3000/api/todos \
  -H "Content-Type: application/json" \
  -d '{"title": "Learn React", "description": "Build a todo app with React and TypeScript"}'
```

#### Get All Todos

```bash
curl http://localhost:3000/api/todos
```

#### Update a Todo

```bash
curl -X PUT http://localhost:3000/api/todos/1 \
  -H "Content-Type: application/json" \
  -d '{"title": "Learn React & TypeScript", "description": "Updated description"}'
```

#### Delete a Todo

```bash
curl -X DELETE http://localhost:3000/api/todos/1
```

## Getting Started

### Prerequisites

- Node.js 18+
- npm

### Installation

```bash
# Install dependencies
npm install

# Generate database migrations
npm run db:generate

# Start development server
npm run dev
```

### Available Scripts

- `npm run dev` - Start development server with hot reload
- `npm run build` - Build for production
- `npm run start` - Start production server
- `npm run db:generate` - Generate database migrations
- `npm run db:migrate` - Run database migrations
- `npm run db:studio` - Open Drizzle Studio (database GUI)

## Tech Stack

- **Hono** - Fast web framework
- **Drizzle ORM** - Type-safe SQL toolkit
- **SQLite** - Lightweight database
- **Zod** - Runtime type validation
- **TypeScript** - Type safety

### Quick Start

```bash
npm install
npm run dev
```

Then open http://localhost:3000
