export const MAX_SHARDS = 10;
