import { NestFactory } from '@nestjs/core';
import { AppModule } from '../app.module';
import axios, { AxiosResponse } from 'axios'; //since one off script used axios directly, instead of creating service
import { Shift, Worker, Workplace } from '@prisma/client';

//modify directly, since pm is using, easier than using env vars
let url = 'http://localhost:3000'

async function bootstrap() {
  const app = await NestFactory.createApplicationContext(AppModule);
  
  const shiftsRes: AxiosResponse<{data: Shift[]}> = await axios.get(`${url}/shifts`);
  const shifts: Shift[] = shiftsRes.data.data
  
  const workplacesRes: AxiosResponse<{data: Workplace[]}> = await axios.get(`${url}/workplaces`);
  const workplaces: Workplace[] = workplacesRes.data.data

  const activeWorkplaceIds = workplaces.filter(workplace => workplace.status === 1)
  const activeWorkplaces = activeWorkplaceIds.map(workplace => ({
    id: workplace.id,
    name: workplace.name,
  }));
  
  const shiftCountByWorkplace: Record<number, number> = {};
  for (const workplace of activeWorkplaces) {
    shiftCountByWorkplace[workplace.id] = 0;
  }
  
  for (const shift of shifts) {
    if (shiftCountByWorkplace[shift.workplaceId] !== undefined) {
      shiftCountByWorkplace[shift.workplaceId]++;
    }
  }
  
  const result = activeWorkplaces.map(workplace => ({
    name: workplace.name,
    shifts: shiftCountByWorkplace[workplace.id] || 0,
  }));
  
  console.log(result);

  await app.close();
}

bootstrap().catch((err) => {
  console.error('Error running the script', err);
  process.exit(1);
});
